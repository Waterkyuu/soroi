package comparison_test

import (
	"testing"
	"time"

	"github.com/Waterkyuu/soroi"
	"github.com/maypok86/otter/v2"
)

const (
	// idleKey is the single key shared by all workers.
	idleKey = "hot"
	// idleValue is the uint64 result established before timing.
	idleValue = uint64(42)
	// idleLimit is the retention window applied to both caches.
	idleLimit = time.Hour
)

// BenchmarkIdleHotKey measures value reads that can renew idle retention.
func BenchmarkIdleHotKey(b *testing.B) {
	b.Run("Soroi", func(b *testing.B) {
		client := soroi.NewClient(soroi.Options{GCTime: idleLimit})
		b.Cleanup(client.Close)
		key := any(idleKey)
		if err := soroi.Set(client, key, idleValue); err != nil {
			b.Fatal(err)
		}
		benchmarkIdleRead(b, func() (uint64, bool) {
			return soroi.Get[uint64](client, key)
		})
	})
	b.Run("Otter", func(b *testing.B) {
		cache := otter.Must(&otter.Options[string, uint64]{
			ExpiryCalculator: otter.ExpiryAccessing[string, uint64](idleLimit),
		})
		b.Cleanup(func() { cache.StopAllGoroutines() })
		cache.Set(idleKey, idleValue)
		benchmarkIdleRead(b, func() (uint64, bool) {
			return cache.GetIfPresent(idleKey)
		})
	})
}

// benchmarkIdleRead checks the same value and presence result for both caches.
func benchmarkIdleRead(b *testing.B, read func() (uint64, bool)) {
	b.Helper()
	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			value, ok := read()
			if !ok || value != idleValue {
				b.Errorf("read = (%d,%t), want (%d,true)", value, ok, idleValue)
				return
			}
		}
	})
}
