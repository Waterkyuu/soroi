package comparison_test

import (
	"sync/atomic"
	"testing"
	"time"

	"github.com/Waterkyuu/soroi"
	"github.com/maypok86/otter/v2"
)

const (
	// hotKey is shared by every benchmark worker.
	hotKey = "hot"
	// hotValue is the scalar result written before timing starts.
	hotValue = uint64(42)
	// hardExpiry controls how long either cache exposes the seeded value.
	hardExpiry = time.Hour
)

// manualClock advances both caches to the same expiry boundary.
type manualClock struct {
	// now holds the test time as a Unix timestamp in nanoseconds.
	now atomic.Int64
}

// NowNano reports the time selected by the expiry test.
func (c *manualClock) NowNano() int64 { return c.now.Load() }

// Tick leaves expiration to reads during the boundary test.
func (c *manualClock) Tick(time.Duration) <-chan time.Time { return nil }

// newSoroiRead prepares a typed value read under Soroi's hard age limit.
func newSoroiRead(tb testing.TB, clock func() time.Time) func() (uint64, bool) {
	tb.Helper()
	client := soroi.NewClient(soroi.Options{MaxAge: hardExpiry, Clock: clock})
	tb.Cleanup(client.Close)
	key := any(hotKey)
	if err := soroi.Set(client, key, hotValue); err != nil {
		tb.Fatal(err)
	}
	return func() (uint64, bool) {
		return soroi.Get[uint64](client, key)
	}
}

// newOtterRead prepares a typed value read under Otter's write expiry.
func newOtterRead(tb testing.TB, clock otter.Clock) func() (uint64, bool) {
	tb.Helper()
	cache := otter.Must(&otter.Options[string, uint64]{
		ExpiryCalculator: otter.ExpiryWriting[string, uint64](hardExpiry),
		Clock:            clock,
	})
	tb.Cleanup(func() { cache.StopAllGoroutines() })
	cache.Set(hotKey, hotValue)
	return func() (uint64, bool) {
		return cache.GetIfPresent(hotKey)
	}
}

// TestHardExpiryBoundary verifies the same observable reads before and at expiration.
func TestHardExpiryBoundary(t *testing.T) {
	base := time.Unix(1_700_000_000, 0)
	clock := &manualClock{}
	clock.now.Store(base.UnixNano())

	soroiRead := newSoroiRead(t, func() time.Time { return time.Unix(0, clock.NowNano()) })
	otterRead := newOtterRead(t, clock)

	for _, age := range []time.Duration{0, hardExpiry - time.Nanosecond, hardExpiry, hardExpiry + time.Nanosecond} {
		clock.now.Store(base.Add(age).UnixNano())
		wantValue, wantOK := hotValue, age < hardExpiry
		if !wantOK {
			wantValue = 0
		}
		soroiValue, soroiOK := soroiRead()
		otterValue, otterOK := otterRead()
		if soroiValue != wantValue || soroiOK != wantOK || otterValue != wantValue || otterOK != wantOK {
			t.Fatalf("age=%s: Soroi=(%d,%t), Otter=(%d,%t), want=(%d,%t)",
				age, soroiValue, soroiOK, otterValue, otterOK, wantValue, wantOK)
		}
		t.Logf("age=%s: Soroi=(%d,%t), Otter=(%d,%t)", age, soroiValue, soroiOK, otterValue, otterOK)
	}
}

// BenchmarkHotKeyHardExpiry measures populated reads with the same key and TTL.
func BenchmarkHotKeyHardExpiry(b *testing.B) {
	b.Run("Soroi", func(b *testing.B) {
		benchmarkHotRead(b, newSoroiRead(b, nil))
	})
	b.Run("Otter", func(b *testing.B) {
		benchmarkHotRead(b, newOtterRead(b, nil))
	})
}

// benchmarkHotRead checks each result under the same timer and loop.
func benchmarkHotRead(b *testing.B, read func() (uint64, bool)) {
	b.Helper()
	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			value, ok := read()
			if !ok || value != hotValue {
				b.Errorf("get = (%d,%t), want (%d,true)", value, ok, hotValue)
				return
			}
		}
	})
}

// BenchmarkHotKeyPlainGet checks the value-read path without expiry maintenance.
func BenchmarkHotKeyPlainGet(b *testing.B) {
	client := soroi.NewClient(soroi.Options{})
	b.Cleanup(client.Close)
	key := any(hotKey)
	if err := soroi.Set(client, key, hotValue); err != nil {
		b.Fatal(err)
	}
	benchmarkHotRead(b, func() (uint64, bool) {
		return soroi.Get[uint64](client, key)
	})
}
