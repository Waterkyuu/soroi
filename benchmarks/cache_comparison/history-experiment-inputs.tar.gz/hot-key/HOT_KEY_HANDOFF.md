# Soroi hot-key performance handoff

The branch `waterkyuu/feat/typed-cache-value` starts at
`release/v0.4.0` (`c237312`). The measured branch baseline is `938547f`.
A separate atomic-publication prototype based on that tip brought eight-worker
pure `Get` from **101.05 to 4.86 ns/op**, versus **3.25 ns/op** for Otter.
The prototype's single-worker `Set` costs rose by **25%–43%**, and exact
`GCTime` remained much slower than Otter's approximate access renewal.

## Reproduce the current comparison

Use Go 1.27.1 to match the recorded results. The comparison module pins
Otter v2.4.0 and the benchmark prepares a shared string key and a small
`uint64` outside the timed section. Run from the repository root on a quiet
machine. These commands build the branch baseline and both research
variants from separate source exports. The archived patches target the
exact baseline revision.

```sh
SOROI_HOT_DIR=$(mktemp -d)
SOROI_HOT_SOURCE="$PWD/benchmarks/cache_comparison"
git archive -o "$SOROI_HOT_DIR/base.tar" 938547f

for variant in current atomic shards; do
  mkdir "$SOROI_HOT_DIR/$variant"
  tar -xf "$SOROI_HOT_DIR/base.tar" -C "$SOROI_HOT_DIR/$variant"
done

git -C "$SOROI_HOT_DIR/atomic" apply --unidiff-zero "$SOROI_HOT_SOURCE/atomic-publication.patch"
git -C "$SOROI_HOT_DIR/shards" apply --unidiff-zero "$SOROI_HOT_SOURCE/reader-shards.patch"

for variant in current atomic shards; do
  go -C "$SOROI_HOT_DIR/$variant/benchmarks/cache_comparison" test -mod=readonly -c \
    -o "$SOROI_HOT_DIR/$variant.test" "$SOROI_HOT_SOURCE/hot_key_benchmark_test.go"
done

for variant in current atomic atomic current; do
  pattern='^BenchmarkAtomicHotKey/Soroi$'
  if [ "$variant" = current ]; then
    pattern='^BenchmarkAtomicHotKey$'
  fi
  "$SOROI_HOT_DIR/$variant.test" -test.run '^$' -test.bench "$pattern" \
    -test.benchmem -test.benchtime=200ms -test.count=3 -test.cpu=1,8 \
    >> "$SOROI_HOT_DIR/$variant.txt"
done
```

Successful runs report `BenchmarkAtomicHotKey/{Soroi,Otter}/{Get,Set}/{Pure,MaxAge,GCTime}`
with and without the `-8` suffix in the baseline. The atomic run reports only
Soroi. Use the median of the six samples per case. For the four-counter
prototype, run `shards.test` with the same flags and
`-test.bench '^BenchmarkAtomicHotKey/Soroi$/^Get$'`. To build the two-counter
variant, change `const bucketReaderShards = 4` to `2` in the exported
`benchmark_reader_shards.go` before compiling a separate binary. The
older sharding run timed only reads at `-test.benchtime=250ms`.
Keep race tests separate from timed runs.
[Benchmark source](hot_key_benchmark_test.go) · [Raw samples](hot-key-darwin-arm64.txt) ·
[Atomic prototype](atomic-publication.patch) · [Reader shard prototype](reader-shards.patch)

## Latest comparison

Apple M3 Pro, Darwin ARM64, Go 1.27.1. Each cell is **one worker / eight
workers** in ns/op. For `RunParallel`, ns/op is elapsed time divided by
completed operations across all workers. A lower figure at eight workers
indicates higher aggregate throughput. Individual latency and p95/p99 need
separate measurements.

| Operation | Soroi `938547f` | Soroi atomic prototype | Otter v2.4.0 |
| --- | ---: | ---: | ---: |
| `Get`, pure | 23.36 / 101.05 | 19.64 / **4.86** | 18.82 / 3.25 |
| `Get`, only `MaxAge` | 58.64 / 114.05 | 49.25 / **12.46** | 31.88 / 5.37 |
| `Get`, only `GCTime` | 68.25 / 128.95 | 47.35 / **83.31** | 43.89 / 7.44 |
| `Set`, pure | 74.17 / 228.15 | 106.20 / 202.70 | 76.53 / 192.60 |
| `Set`, only `MaxAge` | 80.84 / 228.10 | 110.20 / 226.80 | 89.06 / 227.70 |
| `Set`, only `GCTime` | 132.10 / 227.05 | 165.05 / 239.00 | 89.09 / 229.20 |

Soroi uses typed `Get[uint64]`. Otter uses `GetIfPresent`. Each
`Get` case is a warm hit. Each `Set` case repeatedly overwrites the same
key with `42` and `43` in a write-only interval. The pure cases omit
retention settings. Capacity, subscribers, and loads are absent throughout.
The two enabled policies use one hour each, in separate cases. Soroi
`MaxAge` maps to Otter `ExpiryWriting`, and Soroi `GCTime` maps to Otter
`ExpiryAccessing`. The latter policies have different renewal precision.
[Go parallel benchmark contract](https://pkg.go.dev/testing#B.RunParallel) ·
[Otter deadline implementation](https://github.com/maypok86/otter/blob/v2.4.0/deadline.go#L28)

Both Soroi variants allocated zero bytes per read. The branch `Set`
allocated zero, and the prototype allocated **64 B and one object per
overwrite** for its immutable published result. At eight workers, `Set`
median changes ranged from 11% lower to 5% higher across the three policies,
with overlap in several raw samples. This series does not measure mixed
traffic or sustained allocation pressure.

## Landed changes

| Commit | Change | Measured effect on the same key |
| --- | --- | --- |
| `0250a1f` | Split value reads from query-state reads. | Release typed snapshot `Get` at 108.85 / 127.05 became typed value `Get` at 24.27 / 97.89 in the API split run. |
| `e8fa553` | A live `MaxAge` hit uses the bucket read lock with the default clock. An expired read rechecks under the exclusive lock before removing data. | 86.78 / 231.85 to 57.25 / 113.30 in the confirmation run. Otter write expiry was 32.15 / 5.45 in the final binary. |
| `938547f` | Renew the idle deadline without restarting a timer on each read. | 300.00 / 385.25 to 67.12 / 127.90 in the paired `GCTime` run. Otter access expiry was 44.62 / 7.66 across both binaries. Soroi went from 208 B and four allocations per read to zero. |

The medians above come from separate runs. Compare rows within each
experiment. The existing [main versus cache candidate comparison](../../README.md#eight-worker-cached-operations)
uses disjoint worker key ranges across 1,024 keys. The earlier
[Otter comparison](RESULTS.md) uses the snapshot read and one or four workers.
Those tables answer different workload questions from the shared-key study.

### API and retention contracts

- Typed and untyped `Get` return `(value, ok)`. `ok` means a usable
  value is available, including a retained stale value or a cached zero.
  The typed variant also checks the static result type. `GetState` provides
  the original snapshot API, including `HasData`, `Fetching`, `Err`,
  `Status`, `Stale`, `UpdatedAt`, and `ExpiresAt`.
- `StaleTime` controls reuse and refresh decisions. `MaxAge` limits how
  long installed data can be served. `GCTime` controls how long an unowned
  key stays in memory after its last access. Active handles and in-flight
  loads suspend idle collection. Capacity recency and supplied clocks
  keep their existing serialized behavior.
- With the default clock, the landed `Get` holds the bucket read lock and
  updates the per-key task's last-access offset with atomic
  compare-and-swap (CAS). Every read supplies its precise access time, and
  the update keeps the most recent time. The timer callback takes the bucket
  write lock and computes `last access + GCTime`. It rearms for the
  remaining duration or collects the key. Comparing task identities protects
  a replacement from an old callback.
- Otter's hash-table lookup uses atomic loads of bucket metadata and node
  pointers. Its readers do not register with a shared reader counter.
  With `ExpiryAccessing(1h)`, Otter can also skip deadline movements of up
  to one second while both lifetimes exceed that tolerance. Pure Otter
  reads scale in the benchmark even with expiry disabled.

[Cache API and policy guide](../../docs/cache.en-US.md) ·
[Get implementation](../../query.go) · [Idle GC implementation](../../gc.go) ·
[Otter hash table](https://github.com/maypok86/otter/blob/v2.4.0/internal/hashmap/map.go#L203)

## Experiments

### Return shape and type checking

The early runs set Soroi `StaleTime=1h` and used a single prepared key.
Run A set Otter `ExpiryWriting(1h)`. The original Soroi `Get` still
returned a snapshot. Values are one worker / eight workers in ns/op.

| Run A case | Result | Run B case | Result |
| --- | ---: | --- | ---: |
| Typed snapshot `Get` | 107.35 / 124.50 | Typed snapshot `Get` | 102.75 / 121.70 |
| Untyped snapshot `Client.Get` | 95.78 / 123.80 | | |
| Untyped `(value, ok)`, stale values allowed | 20.24 / 102.75 | Untyped `(value, ok)` | 20.58 / 100.35 |
| Untyped `(value, ok)`, fresh values only | 64.16 / 117.40 | Untyped `(value, ok, stale)` | 64.20 / 114.05 |
| Otter `GetIfPresent` | 31.30 / 5.25 | | |

Removing the snapshot and its freshness calculation saved substantial work
at one worker. Skipping only the type check changed the eight-worker case
by less than 1 ns/op in run A. The experimental stale flag required the
freshness clock and age calculation. The final split exposes this state
through `GetState`.

### Distribute the bucket's reader counter

Every baseline hit in this study takes an `RWMutex` read lock. Its entry and exit
atomically update the same reader count for all readers of a bucket. The
prototype selects a shard by the Go scheduler's processor, keeps each shard
on a separate cache line, and makes writers acquire all shards in order.
It uses private runtime functions, with full race tests passing for the two-
and four-shard variants on the benchmark Go version. Values are one worker /
eight workers in ns/op, with six samples per case.

| Get case | One counter | Two counters | Four counters | Otter |
| --- | ---: | ---: | ---: | ---: |
| Pure | 23.54 / 99.83 | 25.68 / 63.20 | 25.60 / 34.58 | 18.74 / 3.14 |
| Only `MaxAge` | 58.32 / 118.55 | 59.95 / 73.96 | 60.47 / 39.08 | 31.79 / 5.33 |
| Only `GCTime` | 65.82 / 127.25 | 67.19 / 91.46 | 67.14 / 78.68 | 43.91 / 7.42 |

Adding four counters reduced the pure eight-worker cost by **65%**.
`GCTime` retains contention on one access timestamp. This run measured
only reads. A separate early experiment with the snapshot `Get`, four
samples per case, measured writes and mixed traffic. The numbers below
are eight-worker ns/op and describe that earlier API and implementation.

| Counter shards per bucket | Get | Set | 99 reads per write | 15 reads per write |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 125.55 | 232.05 | 142.95 | 181.45 |
| 2 | 82.44 | 212.05 | 113.60 | 172.80 |
| 4 | 55.99 | 174.25 | 98.26 | 166.10 |
| 8 | 42.86 | 192.45 | 96.93 | 165.45 |

[Go reader counter](https://go.dev/src/sync/rwmutex.go#L67) ·
[Reader shard prototype](reader-shards.patch)

### Publish one key atomically

The prototype keeps the lifecycle entries under their existing bucket locks.
A per-bucket `sync.Map` indexes a stable slot for each binding. Writers
publish one immutable record with its value, type, and installation time.
Eligible hits use atomic reads without incrementing a reader count. A
generation check covers `Clear` and `Close`. Expired entries, keys whose
GC task has been retired, and policies that need serialized maintenance use
the locked path. `GetState` still reads the lifecycle entry.

On every `GCTime` hit the prototype records precise access with CAS. The
collector also uses CAS to claim the task for retirement, so a renewer that
wins first moves the deadline. A read that sees a retired task checks the
current key again. A controlled test covers renewal racing with collection,
including the last nanosecond before the deadline. Another covers a read
racing with `Remove` and recreation. The prototype also passed the full
race suite and Go 1.22.12 tests.

The two prototypes remain experiments. The pushed branch uses the
original bucket reader count and the coalesced idle timer.
[Atomic prototype](atomic-publication.patch)

### Earlier per-key publication experiments

The diagnostics repository tested the same publication mechanism on
November 12, 2026. Commit `4551ebf` used a `sync.Map` index, a stable slot per
key, and an atomic pointer to a new immutable read record on each eligible
`Set` or `Update`. Eight-worker same-key snapshot `Get` improved from 127.85
to 11.72 ns/op. Distributed `Set` cost increased by 45.84% at one worker
and 46.43% at eight workers, with one additional record allocation per write.
[Eager publication results](https://github.com/Waterkyuu/soroi-performance-diagnostics/blob/c4a67119b982fd1e15c2c2892eabfbd2c1707b76/experiments/eager_read_snapshot/RESULTS.md)

Commit `6b0508b` then reused the record. Writers atomically updated its
fields and published a revision. Readers checked that revision twice before
using the value and timestamps. Eight-worker same-key snapshot `Get`
improved from 125.60 to 14.81 ns/op against its own baseline. Record reuse
removed the extra per-write allocation. Distributed `Set` still cost 14.02%
more at one worker and 9.25% more at eight workers, exceeding that
experiment's 5% guardrail.
The timestamp implementation relied on the private layout of `time.Time`.
[Record reuse results](https://github.com/Waterkyuu/soroi-performance-diagnostics/blob/8af80ec73353c0dbcb8fdc8800eb906a5fa4d934/experiments/reused_read_snapshot/RESULTS.md)

Both earlier fast paths returned full query snapshots with `MaxAge` and
`GCTime` disabled. The current prototype tests the same publication idea
on the value-only `Get`, adds separate `MaxAge` and precise `GCTime` cases,
and measures same-key `Set` and Otter in the same run. Compare changes
against each experiment's own baseline.

## Next investigation

1. Measure the atomic prototype under same-key and distributed-key mixed
   traffic, including 99:1 and 15:1 read/write ratios. Record `Set` cost,
   allocations and GC pressure, and compare with `938547f`. The
   one-worker write regression is the largest measured cost of adoption.
2. Isolate the idle timestamp update with a controlled diagnostic
   benchmark. The current data shows contention remains after removing
   the reader counter. It does not quantify the timestamp CAS separately
   from time reads, indexing, and task checks. Keep precise renewal in
   any candidate intended to ship.
3. Before considering integration, rerun boundary and race tests for
   `MaxAge`, renewal and collection, `Set`/load races, `Remove`,
   `Clear`, and `Close`. Measure capacity and custom-clock behavior
   separately, and repeat the performance comparison on Linux if it is
   a target deployment platform.
