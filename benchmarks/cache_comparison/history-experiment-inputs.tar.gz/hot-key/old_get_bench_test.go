package compare_test

import (
	"testing"
	"time"

	"github.com/Waterkyuu/soroi"
)

func BenchmarkHotGet(b *testing.B) {
	key := any("hot")
	const want = uint64(42)
	client := soroi.NewClient(soroi.Options{StaleTime: time.Hour})
	b.Cleanup(client.Close)
	if err := soroi.Set(client, key, want); err != nil {
		b.Fatal(err)
	}

	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			state := soroi.Get[uint64](client, key)
			value, ok := state.Data, state.HasData
			if !ok || value != want {
				b.Errorf("get = (%d, %v)", value, ok)
				return
			}
		}
	})
}
