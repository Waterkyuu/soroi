package comparison_test

import (
	"testing"
	"time"

	"github.com/Waterkyuu/soroi"
	"github.com/maypok86/otter/v2"
)

const (
	// hotKey is shared by all benchmark workers.
	hotKey = "hot"
	// hotValue is the expected value returned by all cache reads.
	hotValue = uint64(42)
	// retentionInterval keeps the value live throughout a benchmark sample.
	retentionInterval = time.Hour
)

// BenchmarkHotKey measures typed value reads with the same three retention setups.
func BenchmarkHotKey(b *testing.B) {
	cases := []struct {
		name   string
		soroi  soroi.Options
		expiry otter.ExpiryCalculator[string, uint64]
	}{
		{name: "Pure"},
		{
			name:   "MaxAge",
			soroi:  soroi.Options{MaxAge: retentionInterval},
			expiry: otter.ExpiryWriting[string, uint64](retentionInterval),
		},
		{
			name:   "GCTime",
			soroi:  soroi.Options{GCTime: retentionInterval},
			expiry: otter.ExpiryAccessing[string, uint64](retentionInterval),
		},
	}
	for _, tc := range cases {
		b.Run("Soroi/"+tc.name, func(b *testing.B) {
			client := soroi.NewClient(tc.soroi)
			b.Cleanup(client.Close)
			key := any(hotKey)
			if err := soroi.Set(client, key, hotValue); err != nil {
				b.Fatal(err)
			}
			benchmarkHotRead(b, func() (uint64, bool) {
				return soroi.Get[uint64](client, key)
			})
		})
		b.Run("Otter/"+tc.name, func(b *testing.B) {
			cache := otter.Must(&otter.Options[string, uint64]{ExpiryCalculator: tc.expiry})
			b.Cleanup(func() { cache.StopAllGoroutines() })
			cache.Set(hotKey, hotValue)
			benchmarkHotRead(b, func() (uint64, bool) {
				return cache.GetIfPresent(hotKey)
			})
		})
	}
}

// benchmarkHotRead checks that every worker reads the same installed value.
func benchmarkHotRead(b *testing.B, read func() (uint64, bool)) {
	b.Helper()
	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			value, ok := read()
			if !ok || value != hotValue {
				b.Errorf("Get = (%d, %t), want (%d, true)", value, ok, hotValue)
				return
			}
		}
	})
}
