package comparison_test

import (
	"testing"
	"time"

	"github.com/Waterkyuu/soroi"
)

func BenchmarkUntyped(b *testing.B) {
	client := soroi.NewClient(soroi.Options{GCTime: time.Hour})
	b.Cleanup(client.Close)
	key := any("hot")
	const want = uint64(42)
	if err := soroi.Set(client, key, want); err != nil {
		b.Fatal(err)
	}
	if value, ok := client.Get(key); !ok || value != want {
		b.Fatalf("preflight Get = %v, %t", value, ok)
	}
	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			if _, ok := client.Get(key); !ok {
				b.Error("unexpected cache miss")
				return
			}
		}
	})
	b.StopTimer()
	if value, ok := client.Get(key); !ok || value != want {
		b.Fatalf("final Get = %v, %t", value, ok)
	}
}

func BenchmarkTyped(b *testing.B) {
	client := soroi.NewClient(soroi.Options{GCTime: time.Hour})
	b.Cleanup(client.Close)
	key := any("hot")
	const want = uint64(42)
	if err := soroi.Set(client, key, want); err != nil {
		b.Fatal(err)
	}
	if value, ok := soroi.Get[uint64](client, key); !ok || value != want {
		b.Fatalf("preflight Get = %v, %t", value, ok)
	}
	b.ReportAllocs()
	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			if _, ok := soroi.Get[uint64](client, key); !ok {
				b.Error("unexpected cache miss")
				return
			}
		}
	})
	b.StopTimer()
	if value, ok := soroi.Get[uint64](client, key); !ok || value != want {
		b.Fatalf("final Get = %v, %t", value, ok)
	}
}
