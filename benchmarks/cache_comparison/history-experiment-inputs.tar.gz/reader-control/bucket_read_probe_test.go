package soroi

import (
	"fmt"
	"runtime"
	"sync/atomic"
	"testing"
	"time"
)

// BenchmarkDistinctReads measures concurrent public Get calls after populating a fixed read-only working set.
func BenchmarkDistinctReads(b *testing.B) {
	for _, layout := range []string{"OneBucket", "SeparateBuckets", "Natural1024"} {
		b.Run(layout, func(b *testing.B) {
			workers := runtime.GOMAXPROCS(0)
			client := NewClient(Options{GCTime: time.Hour})
			// Both binaries use a real clock and real idle tasks. No cleanup callback may write
			// to the map during the diagnostic run that omits read-side locking.
			client.gcAfterFunc = func(time.Duration, func()) func() { return func() {} }
			b.Cleanup(client.Close)
			keys := make([][]any, workers)
			perWorker := 1
			if layout == "Natural1024" {
				perWorker = 1024 / workers
			}
			n := 0
			for w := range workers {
				for len(keys[w]) < perWorker {
					key := any(fmt.Sprintf("key-%08x", n))
					n++
					bucket := client.bucketFor(key).index
					if layout == "OneBucket" && bucket != 0 {
						continue
					}
					if layout == "SeparateBuckets" && bucket != w*(len(client.buckets)/workers) {
						continue
					}
					if err := Set(client, key, 42); err != nil {
						b.Fatal(err)
					}
					keys[w] = append(keys[w], key)
				}
			}
			var assigned atomic.Int32
			b.ReportAllocs()
			b.ResetTimer()
			b.RunParallel(func(pb *testing.PB) {
				local := keys[int(assigned.Add(1))-1]
				mask := len(local) - 1
				i := 0
				for pb.Next() {
					key := local[i&mask]
					i++
					if _, ok := client.Get(key); !ok {
						b.Error("missing preloaded key")
						return
					}
				}
			})
			b.StopTimer()
		})
	}
}
